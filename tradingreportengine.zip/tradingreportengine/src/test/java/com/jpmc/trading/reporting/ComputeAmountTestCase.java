package com.jpmc.trading.reporting;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.jpmc.trading.reporting.domainobjects.Instruction;
import com.jpmc.trading.reporting.util.DateUtils;

import net.jpmc.trading.reporting.constants.CurrencyEnum;
import net.jpmc.trading.reporting.constants.InstructionStatusEnum;
import net.jpmc.trading.reporting.service.InstructionReportService;

public class ComputeAmountTestCase {

	@Test
	public void computeBuyAmountTest() throws Exception {
		Instruction instruction1 = new Instruction("entity1", InstructionStatusEnum.BUY, new BigDecimal("0.50"), CurrencyEnum.SGP, DateUtils.getFormattedDate("01 Jan 2016"), DateUtils.getFormattedDate("17 May 2017"), 200L, new BigDecimal("100.25"));
		Instruction instruction2 = new Instruction("entity1", InstructionStatusEnum.BUY, new BigDecimal("0.50"), CurrencyEnum.SGP, DateUtils.getFormattedDate("01 Jan 2016"), DateUtils.getFormattedDate("18 May 2017"), 200L, new BigDecimal("100.25"));
		BigDecimal referenceAmount = instruction1.getPricePerUnit().multiply(new BigDecimal(instruction1.getUnits()))
		.multiply(instruction1.getAgreedFX());
		List<Instruction> instructions = new ArrayList<>();
		instructions.add(instruction1);
		instructions.add(instruction2);
		InstructionReportService instructionReportService = new InstructionReportService();
		BigDecimal computedAmount = instructionReportService.computeSettledOutgoing(instructions);
		assertEquals(computedAmount, referenceAmount);
	}
	
	@Test
	public void computeSellAmountTest() throws Exception {
		Instruction instruction1 = new Instruction("entity1", InstructionStatusEnum.SELL, new BigDecimal("0.50"), CurrencyEnum.SGP, DateUtils.getFormattedDate("01 Jan 2016"), DateUtils.getFormattedDate("17 May 2017"), 200L, new BigDecimal("100.25"));
		Instruction instruction2 = new Instruction("entity1", InstructionStatusEnum.SELL, new BigDecimal("0.50"), CurrencyEnum.SGP, DateUtils.getFormattedDate("01 Jan 2016"), DateUtils.getFormattedDate("18 May 2017"), 200L, new BigDecimal("100.25"));
		BigDecimal referenceAmount = instruction1.getPricePerUnit().multiply(new BigDecimal(instruction1.getUnits()))
		.multiply(instruction1.getAgreedFX());
		List<Instruction> instructions = new ArrayList<>();
		instructions.add(instruction1);
		instructions.add(instruction2);
		InstructionReportService instructionReportService = new InstructionReportService();
		BigDecimal computedAmount = instructionReportService.computeSettledIncoming(instructions);
		assertEquals(computedAmount, referenceAmount);
	}
	
	
}
