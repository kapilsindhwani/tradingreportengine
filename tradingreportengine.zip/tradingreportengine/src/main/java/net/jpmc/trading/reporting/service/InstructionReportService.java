package net.jpmc.trading.reporting.service;

import java.math.BigDecimal;
import java.util.List;

import com.jpmc.trading.reporting.businessobjects.InstructionReportBusinessObject;
import com.jpmc.trading.reporting.domainobjects.Instruction;

/**
 * @author e748450
 *
 */
public class InstructionReportService {

	/**
     * Computes amount in USD settled outgoing everyday
	 * @param instructions Instructions containing the entity details e.g. Buy/Sell, Settlement Date etc.
	 * @return Computed amount in USD settled outgoing everyday
	 * @throws Exception 
	 */
	public BigDecimal computeSettledOutgoing(List<Instruction> instructions) throws Exception{
		InstructionReportBusinessObject instructionReportBusinessObject=new InstructionReportBusinessObject();
		return instructionReportBusinessObject.computeSettledOutgoing(instructions);
	}
	/**
     * Computes amount in USD settled incoming everyday
	 * @param instructions Instructions containing the entity details e.g. Buy/Sell, Settlement Date etc.
	 * @return Computed amount in USD settled incoming everyday
	 * @throws Exception 
	 */
	public BigDecimal computeSettledIncoming(List<Instruction> instructions) throws Exception{
		InstructionReportBusinessObject instructionReportBusinessObject=new InstructionReportBusinessObject();
		return instructionReportBusinessObject.computeSettledIncoming(instructions);
	}
	
	/**
	 * Ranking of entities based on outgoing
	 * @param instructions Instructions containing the entity details e.g. Buy/Sell, Settlement Date etc.
	 * @throws Exception 
	 */
	public void rankOutgoing(List<Instruction> instructions) throws Exception{
		InstructionReportBusinessObject instructionReportBusinessObject=new InstructionReportBusinessObject();
		instructionReportBusinessObject.rankOutgoing(instructions);
	}
	
	/**
	 * Ranking of entities based on incoming
	 * @param instructions Instructions containing the entity details e.g. Buy/Sell, Settlement Date etc.
	 * @throws Exception 
	 */
	public void rankIncoming(List<Instruction> instructions) throws Exception{
		InstructionReportBusinessObject instructionReportBusinessObject=new InstructionReportBusinessObject();
		instructionReportBusinessObject.rankIncoming(instructions);
	}
	
}
