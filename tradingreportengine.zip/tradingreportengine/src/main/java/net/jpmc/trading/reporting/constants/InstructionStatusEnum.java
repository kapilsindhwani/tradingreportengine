package net.jpmc.trading.reporting.constants;


public enum InstructionStatusEnum {
	BUY("B"),
	SELL("S");
	
	private final String value;
	
	InstructionStatusEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static InstructionStatusEnum fromValue(String v) {
        for (InstructionStatusEnum c: InstructionStatusEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
