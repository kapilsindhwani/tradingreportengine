package net.jpmc.trading.reportingengine;

import java.util.List;
import java.util.Scanner;

import com.jpmc.trading.reporting.domainobjects.Instruction;
import com.jpmc.trading.reporting.helper.LoadInstructionsHelper;

import net.jpmc.trading.reporting.service.InstructionReportService;

public class Application {
	
	public static void main(String[] args) throws Exception {
		inputMenu();
	}

	public static void inputMenu() throws Exception {
		LoadInstructionsHelper loadInstructionsHelper = new LoadInstructionsHelper();
		List<Instruction> instructions = loadInstructionsHelper.loadInstructions();
		Scanner in = new Scanner(System.in);
		displayMenu(in);
		InstructionReportService instructionReportService = new InstructionReportService();

		switch (in.nextInt()) {
		case 1:
			System.out.println("*********************Output Start****************************");
			System.out.println("Settled Incoming Amount for today is:"
					+ instructionReportService.computeSettledIncoming(instructions));
			System.out.println("**********************Output End*****************************");
			prompt(in);
			break;

		case 2:
			System.out.println("*********************Output Start****************************");
			System.out.println("Settled Outgoing Amount for today is:"
					+ instructionReportService.computeSettledOutgoing(instructions));
			System.out.println("**********************Output End*****************************");
			prompt(in);
			break;

		case 3:
			System.out.println("*********************Output Start****************************");
			System.out.println(":::::::::::Outgoing rank:::::::::::");
			System.out.println("Entity\t\tAmount(in USD)");
			
			instructionReportService.rankOutgoing(instructions);
			System.out.println("\n");
			System.out.println(":::::::::::Imcoming rank:::::::::::");
			System.out.println("Entity\t\tAmount(in USD)");
			instructionReportService.rankIncoming(instructions);
			System.out.println("\n");
			System.out.println("**********************Output End*****************************");
			prompt(in);
			break;
		default:
			System.err.println("Unrecognized option");
			inputMenu();
			break;
		}
	}

	private static void displayMenu(Scanner in) throws Exception{
		System.out.println("::::::::::::::::::::::::::Main Menu:::::::::::::::::::::");
		System.out.print("1:\tView Amount in USD settled incoming everyday\n");
		System.out.print("2:\tView Amount in USD settled outgoing everyday\n");
		System.out.print("3:\tView Ranking of entities based on incoming and outgoing amount\n");
		//System.out.print("4:\tExit!\n");
	}

	public static void prompt(Scanner in) throws Exception {
		System.out.println("9:\tTo go to Main Menu.");
		System.out.println("0:\tTo quit.");
		switch (in.nextInt()) {
		case 0:
			System.out.println("Exiting.");
			in.close();
			break;

		case 9:
			inputMenu();
			break;
		default:
			System.err.println("Unrecognized option");
			prompt(in);
			break;
		}
	}

}
