package net.jpmc.trading.reporting.constants;


public enum CurrencyEnum {
	SGP("SGP"),
	AED("SGP"),
	USD("SAR"),
	SAR("USD");
	
	private final String value;
	
	CurrencyEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CurrencyEnum fromValue(String v) {
        for (CurrencyEnum c: CurrencyEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
