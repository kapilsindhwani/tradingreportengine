package com.jpmc.trading.reporting.domainobjects;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.jpmc.trading.reporting.util.ComputingUtils;

import net.jpmc.trading.reporting.constants.CurrencyEnum;
import net.jpmc.trading.reporting.constants.InstructionStatusEnum;

public class Instruction implements Comparable<Instruction>{

	private String entity;
	private InstructionStatusEnum instructionStatus;
	private BigDecimal agreedFX;
	private CurrencyEnum currency;
	private LocalDate instructionDate;
	private LocalDate settlementDate;
	private Long units;
	private BigDecimal pricePerUnit;

	// This is a temporary constructor only for the purpose of creating sample
	// data
	public Instruction(String entity, InstructionStatusEnum instructionStatus, BigDecimal agreedFX,
			CurrencyEnum currency, LocalDate instructionDate, LocalDate settlementDate, Long units,
			BigDecimal pricePerUnit) {
		this.entity = entity;
		this.instructionStatus = instructionStatus;
		this.agreedFX = agreedFX;
		this.currency = currency;
		this.instructionDate = instructionDate;
		this.settlementDate = settlementDate;
		this.units = units;
		this.pricePerUnit = pricePerUnit;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public InstructionStatusEnum getInstructionStatus() {
		return instructionStatus;
	}

	public void setInstructionStatus(InstructionStatusEnum instructionStatus) {
		this.instructionStatus = instructionStatus;
	}

	public BigDecimal getAgreedFX() {
		return agreedFX;
	}

	public void setAgreedFX(BigDecimal agreedFX) {
		this.agreedFX = agreedFX;
	}

	public CurrencyEnum getCurrency() {
		return currency;
	}

	public void setCurrency(CurrencyEnum currency) {
		this.currency = currency;
	}

	public LocalDate getInstructionDate() {
		return instructionDate;
	}

	public void setInstructionDate(LocalDate instructionDate) {
		this.instructionDate = instructionDate;
	}

	public LocalDate getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(LocalDate settlementDate) {
		this.settlementDate = settlementDate;
	}

	public Long getUnits() {
		return units;
	}

	public void setUnits(Long units) {
		this.units = units;
	}

	public BigDecimal getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(BigDecimal pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	@Override
	public int compareTo(Instruction instruction) {
		return ComputingUtils.getResult(this).compareTo(ComputingUtils.getResult(instruction));
	}

}
