package com.jpmc.trading.reporting.util;

import java.math.BigDecimal;

import com.jpmc.trading.reporting.domainobjects.Instruction;

import net.jpmc.trading.reporting.constants.InstructionStatusEnum;

public class ComputingUtils {

	public static BigDecimal getResult(Instruction instruction) {
		return instruction.getPricePerUnit().multiply(new BigDecimal(instruction.getUnits()))
				.multiply(instruction.getAgreedFX());
	}

	public static boolean isBuy(Instruction instruction) {
		if (instruction.getInstructionStatus().equals(InstructionStatusEnum.BUY)) {
			return true;
		}
		return false;
	}

	public static boolean isSell(Instruction instruction) {
		if (instruction.getInstructionStatus().equals(InstructionStatusEnum.SELL)) {
			return true;
		}
		return false;
	}

}
