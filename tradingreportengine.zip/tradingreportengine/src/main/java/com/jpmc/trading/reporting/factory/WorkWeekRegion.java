package com.jpmc.trading.reporting.factory;

import java.time.LocalDate;

public interface WorkWeekRegion {

	/**
	 * @return
	 */
	String getWorkWeek() throws Exception;
	/**
	 * @return
	 */
	LocalDate getNextBusinessDate() throws Exception;
	/**
	 * @return
	 */
	LocalDate getPreviousBusinessDate() throws Exception;
}
