package com.jpmc.trading.reporting.util;

import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtils {

	private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
	
	private static String ZONE = "UTC";
	
	public static Date asDate(LocalDate localDate) {
	    return Date.from(localDate.atStartOfDay().atZone(ZoneId.of(ZONE)).toInstant());
	  }

	  public static Date asDate(LocalDateTime localDateTime) {
	    return Date.from(localDateTime.atZone(ZoneId.of(ZONE)).toInstant());
	  }

	  public static LocalDate asLocalDate(Date date) {
	    return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.of(ZONE)).toLocalDate();
	  }

	  public static LocalDateTime asLocalDateTime(Date date) {
	    return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.of(ZONE)).toLocalDateTime();
	  }
	  
	  public static LocalDate getFormattedDate(String dateinString) throws ParseException
	  {
		  LocalDate formatted = LocalDate.parse(dateinString,formatter);
		  return formatted;
	  }
	  
	  public static LocalDate today()
	  {
		  return LocalDate.now(ZoneId.of(ZONE));
	  }
	  
	  public static String getTimeZone(){
		  return ZONE;
	  }

}
