package com.jpmc.trading.reporting.businessobjects;

import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.quartz.CronExpression;

import com.jpmc.trading.reporting.domainobjects.Instruction;
import com.jpmc.trading.reporting.factory.WorkWeekFactory;
import com.jpmc.trading.reporting.factory.WorkWeekRegion;
import com.jpmc.trading.reporting.util.ComputingUtils;
import com.jpmc.trading.reporting.util.DateUtils;

import net.jpmc.trading.reporting.constants.InstructionStatusEnum;

/**
 * @author e748450
 *
 */
public class InstructionReportBusinessObject {

	/**
	 * @param instructions
	 * @return
	 * @throws Exception 
	 */
	public BigDecimal computeSettledOutgoing(List<Instruction> instructions) throws Exception {
		BigDecimal outgoingSum = BigDecimal.ZERO;
		for (Instruction instruction : instructions) {
			if (ComputingUtils.isBuy(instruction)) {
				outgoingSum = outgoingSum.add(settledAmount(instruction));
			}
		}
		return outgoingSum;
	}

	/**
	 * @param instructions
	 * @return
	 * @throws Exception 
	 */
	public BigDecimal computeSettledIncoming(List<Instruction> instructions) throws Exception {
		BigDecimal incomingSum = BigDecimal.ZERO;
		for (Instruction instruction : instructions) {
			if (ComputingUtils.isSell(instruction)) {
				incomingSum = incomingSum.add(settledAmount(instruction));
			}
		}
		return incomingSum;
	}

	/**
	 * @param instructions
	 * @return
	 * @throws Exception 
	 */
	public Map<String, BigDecimal> rankOutgoing(List<Instruction> instructions) throws Exception {
		Map<String, BigDecimal> entityMap = new HashMap<String, BigDecimal>();
		for (Instruction instruction : instructions) {
			if (instruction.getInstructionStatus().equals(InstructionStatusEnum.BUY)) {
				combineEntityTotal(entityMap, instruction);
			}
		}
		sortRank(entityMap);
		return entityMap;
	}

	/**
	 * @param instructions
	 * @throws Exception 
	 */
	public void rankIncoming(List<Instruction> instructions) throws Exception {
		Map<String, BigDecimal> entityMap = new HashMap<String, BigDecimal>();
		for (Instruction instruction : instructions) {
			if (instruction.getInstructionStatus().equals(InstructionStatusEnum.SELL)) {
				combineEntityTotal(entityMap, instruction);
			}
		}
		sortRank(entityMap);
	}

	/**
	 * @param instruction
	 * @return
	 */
	private BigDecimal settledAmount(Instruction instruction) throws Exception {
		BigDecimal settledAmount = BigDecimal.ZERO;

		if (isSettlementDue(instruction)) {
			instruction.setSettlementDate(LocalDate.now());
			settledAmount = instruction.getPricePerUnit().multiply(new BigDecimal(instruction.getUnits()))
					.multiply(instruction.getAgreedFX());
		}

		return settledAmount;
	}

	/**
	 * @param instruction
	 * @return
	 * @throws ParseException
	 */
	private boolean isSettlementDue(Instruction instruction) throws Exception {
		WorkWeekFactory workWeekFactory = new WorkWeekFactory();
		WorkWeekRegion workWeekRegion = workWeekFactory.getWorkWeekRegion(instruction.getCurrency());
		CronExpression expression = new CronExpression(workWeekRegion.getWorkWeek());
		expression.setTimeZone(TimeZone.getTimeZone(DateUtils.getTimeZone()));
		LocalDate today = DateUtils.today();
		if (today.equals(instruction.getSettlementDate()) && expression.isSatisfiedBy(DateUtils.asDate(today))
				|| (instruction.getSettlementDate().isAfter(workWeekRegion.getPreviousBusinessDate())
						&& instruction.getSettlementDate().isBefore(workWeekRegion.getNextBusinessDate())
						&& expression.isSatisfiedBy(DateUtils.asDate(today)))) {
			return true;
		}
		return false;
	}

	/**
	 * @param entityMap
	 * @param instruction
	 * @throws Exception 
	 */
	private void combineEntityTotal(Map<String, BigDecimal> entityMap, Instruction instruction) throws Exception {
		if (!entityMap.containsKey(instruction.getEntity())) {
			entityMap.put(instruction.getEntity(), settledAmount(instruction));
		} else {
			BigDecimal amount = entityMap.get(instruction.getEntity());
			entityMap.put(instruction.getEntity(), settledAmount(instruction).add(amount));
		}
	}

	/**
	 * @param entityMap
	 */
	private void sortRank(Map<String, BigDecimal> entityMap) {

		entityMap.entrySet().parallelStream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
				.forEachOrdered(s -> System.out.println(s.getKey() + "\t\t" + s.getValue()));

	}

}
