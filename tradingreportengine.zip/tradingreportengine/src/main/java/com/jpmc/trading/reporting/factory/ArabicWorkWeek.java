package com.jpmc.trading.reporting.factory;

public class ArabicWorkWeek extends WorkWeekRegionAbstract{
	
	/**
     * Provides Arabic Work week e.g. Arabic work week is Sunday to Friday 
	 * @param
	 * @return
	 */
	public String getWorkWeek() {
		String cron = "* * 0-23 ? * SUN-THU";
		return cron; 
	}

	
	
	
}
