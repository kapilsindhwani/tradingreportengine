package com.jpmc.trading.reporting.factory;

import net.jpmc.trading.reporting.constants.CurrencyEnum;


public class WorkWeekFactory {

	/**
	 * This Factory class will create an object of WorkWeek based on the currency e.g. AED and SAR have work week of SUNDAY to THURSDAY
	 * @param inputCurrency
	 * @return
	 */
	public WorkWeekRegion getWorkWeekRegion(CurrencyEnum inputCurrency) {

		WorkWeekRegion workWeekRegion = null;
		switch (inputCurrency) {
		case AED:
		case SAR:
			workWeekRegion = new ArabicWorkWeek();
			break;
		default:
			workWeekRegion = new NonArabicWorkWeek();
			break;

		}
		return workWeekRegion;
	}
}
