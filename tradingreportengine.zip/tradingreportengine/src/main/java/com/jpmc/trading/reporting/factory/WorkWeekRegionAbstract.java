package com.jpmc.trading.reporting.factory;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.TimeZone;

import org.quartz.CronExpression;

import com.jpmc.trading.reporting.util.DateUtils;

public abstract class WorkWeekRegionAbstract implements WorkWeekRegion {

	/** 
	 * Provides Next Business Date for Work region 
	 * e.g. Arabic work week is Sunday to Thursday. This method will return Sunday as the next business date if run on Friday
	 * @throws Exception 
	 * 
	 */
	@Override
	public LocalDate getNextBusinessDate() throws Exception {
		LocalDate today = DateUtils.today();
		return(getNextBusinessDate(today.plusDays(1)));
	}

	/**
	 * @param businessDate
	 * @return
	 * @throws ParseException
	 */
	private LocalDate getNextBusinessDate(LocalDate businessDate) throws Exception {

		CronExpression expression = new CronExpression(getWorkWeek());
		expression.setTimeZone(TimeZone.getTimeZone(DateUtils.getTimeZone()));
		if (expression.isSatisfiedBy(DateUtils.asDate(businessDate))) {
			return businessDate;
		} else {
			return getNextBusinessDate(businessDate.plusDays(1));
		}
	}

	/** 
	 * Provides Next Business Date for Work region 
	 * e.g. Arabic work week is Sunday to Thursday. This method will return Thursday as the previous business date if run on Saturday
	 * 
	 */
	@Override
	public LocalDate getPreviousBusinessDate() throws Exception{
		LocalDate previousBusinessDate = null;
		LocalDate today = DateUtils.today();
		previousBusinessDate = getPreviousBusinessDate(today.minusDays(1));
		return previousBusinessDate;
	}

	/**
	 * @param businessDate
	 * @return
	 * @throws ParseException
	 */
	private LocalDate getPreviousBusinessDate(LocalDate businessDate) throws Exception {
		CronExpression expression = new CronExpression(getWorkWeek());
		expression.setTimeZone(TimeZone.getTimeZone(DateUtils.getTimeZone()));
		if (expression.isSatisfiedBy(DateUtils.asDate(businessDate))) {
			return businessDate;
		} else {
			return getPreviousBusinessDate(businessDate.minusDays(1));
		}
	}
}
