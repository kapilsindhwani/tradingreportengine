package com.jpmc.trading.reporting.helper;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.jpmc.trading.reporting.domainobjects.Instruction;
import com.jpmc.trading.reporting.util.DateUtils;

import net.jpmc.trading.reporting.constants.CurrencyEnum;
import net.jpmc.trading.reporting.constants.InstructionStatusEnum;

public class LoadInstructionsHelper {

	/**
	 * Loads Instruction for various computations Change Settlement date to run
	 * for different dates
	 * @return Instructions
	 * @throws ParseException
	 */
	public List<Instruction> loadInstructions() throws Exception {

		String instructionDate = "17 May 2017";
		String settlementDate = "17 May 2017";
		List<Instruction> instructions = new ArrayList<>();
		addInstruction(instructions,
				new Instruction("entity1", InstructionStatusEnum.BUY, new BigDecimal("0.50"), CurrencyEnum.SGP,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 200L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity2", InstructionStatusEnum.BUY, new BigDecimal("0.50"), CurrencyEnum.SGP,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 100L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity2", InstructionStatusEnum.BUY, new BigDecimal("0.50"), CurrencyEnum.AED,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 100L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity2", InstructionStatusEnum.BUY, new BigDecimal("0.10"), CurrencyEnum.SGP,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 50L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity3", InstructionStatusEnum.BUY, new BigDecimal("0.50"), CurrencyEnum.SGP,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 100L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity3", InstructionStatusEnum.SELL, new BigDecimal("0.22"), CurrencyEnum.AED,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 300L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity4", InstructionStatusEnum.SELL, new BigDecimal("0.22"), CurrencyEnum.USD,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 50L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity5", InstructionStatusEnum.SELL, new BigDecimal("0.23"), CurrencyEnum.USD,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 50L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity6", InstructionStatusEnum.SELL, new BigDecimal("0.24"), CurrencyEnum.SAR,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 50L,
						new BigDecimal("100.25")));
		addInstruction(instructions,
				new Instruction("entity7", InstructionStatusEnum.SELL, new BigDecimal("0.25"), CurrencyEnum.USD,
						DateUtils.getFormattedDate(instructionDate), DateUtils.getFormattedDate(settlementDate), 50L,
						new BigDecimal("100.25")));
		return instructions;
	}

	private void addInstruction(List<Instruction> instructions, Instruction instruction) {
		instructions.add(instruction);
	}
}
