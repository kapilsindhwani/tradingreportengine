package com.jpmc.trading.reporting.factory;

public class NonArabicWorkWeek extends WorkWeekRegionAbstract{

	/* (non-Javadoc)
	 * @see net.jpmc.trading.factory.WorkWeekRegion#getWorkWeek()
	 */
	public String getWorkWeek() {
		String cron = "* * 0-23 ? * MON-FRI";
		return cron; 
	}
}
